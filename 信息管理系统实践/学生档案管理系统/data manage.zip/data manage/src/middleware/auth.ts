import { NextFunction, Request, Response } from "express";
import { Role } from "../types/index.js";
import { verifyToken } from "../utils/jwt.js";

export interface AuthedRequest extends Request {
  user?: {
    userId: bigint;
    role: Role;
    username: string;
  };
}

export function auth(requiredRoles?: Role[]) {
  return (req: AuthedRequest, res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith("Bearer ")) {
      return res.status(401).json({ message: "未授权" });
    }
    const token = authHeader.substring(7);
    try {
      const payload = verifyToken(token);
      req.user = payload;
      if (requiredRoles && !requiredRoles.includes(payload.role)) {
        return res.status(403).json({ message: "权限不足" });
      }
      next();
    } catch (error) {
      return res.status(401).json({ message: "令牌无效或已过期" });
    }
  };
}












