import { Router } from "express";
import { authRouter } from "./routes/auth.routes.js";
import { userRouter } from "./routes/users.routes.js";
import { studentRouter } from "./routes/students.routes.js";
import { classRouter } from "./routes/classes.routes.js";
import { awardRouter } from "./routes/awards.routes.js";
import { statsRouter } from "./routes/stats.routes.js";
import { systemRouter } from "./routes/system.routes.js";
import { viewsRouter } from "./routes/views.routes.js";

export const router = Router();

router.use("/auth", authRouter);
router.use("/users", userRouter);
router.use("/students", studentRouter);
router.use("/classes", classRouter);
router.use("/awards", awardRouter);
router.use("/stats", statsRouter);
router.use("/system", systemRouter);
router.use("/views", viewsRouter);




