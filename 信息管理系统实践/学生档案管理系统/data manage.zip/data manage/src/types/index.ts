export enum Role {
  admin = "admin",
  teacher = "teacher",
  operator = "operator",
}

export enum Gender {
  male = "male",
  female = "female",
  other = "other",
}

export enum Status {
  enrolled = "enrolled",
  suspended = "suspended",
  withdrawn = "withdrawn",
  graduated = "graduated",
}

export enum AwardType {
  award = "award",
  punishment = "punishment",
}

export interface User {
  id: bigint;
  username: string;
  password_hash: string;
  role: Role;
  realname: string | null;
  status: number;
}

export interface Class {
  id: bigint;
  name: string;
  grade: string | null;
}

export interface Student {
  id: bigint;
  student_no: string;
  name: string;
  gender: Gender;
  nation: string | null;
  birthday: Date | null;
  id_card: string | null;
  class_id: bigint | null;
  status: Status;
  enroll_date: Date | null;
  graduate_date: Date | null;
  remark: string | null;
}

export interface AwardsPunishment {
  id: bigint;
  student_id: bigint;
  type: AwardType;
  title: string;
  level: string | null;
  date: Date;
  description: string | null;
}

export interface Settings {
  id: bigint;
  key: string;
  value: string | null;
}

export interface StudentWithRelations extends Student {
  Class?: Class | null;
  Awards?: AwardsPunishment[];
}

export interface CreateUserData {
  username: string;
  password: string;
  role?: Role;
  realname?: string;
}

export interface UpdateUserData {
  username?: string;
  role?: Role;
  realname?: string;
  status?: number;
}

export interface CreateStudentData {
  studentNo: string;
  name: string;
  gender?: Gender;
  nation?: string;
  birthday?: Date | string;
  idCard?: string;
  classId?: bigint;
  status?: Status;
  enrollDate?: Date | string;
  graduateDate?: Date | string;
  remark?: string;
}

export interface UpdateStudentData extends Partial<CreateStudentData> {}

export interface CreateAwardData {
  studentId: bigint;
  type: AwardType;
  title: string;
  level?: string;
  date: Date | string;
  description?: string;
}

export interface UpdateAwardData extends Partial<CreateAwardData> {}

