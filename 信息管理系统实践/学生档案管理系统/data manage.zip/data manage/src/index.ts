import { createApp } from "./app.js";
import { env } from "./config/env.js";
import { initViewsAndTriggers, initProcedures } from "./utils/db-init.js";

// @ts-ignore
BigInt.prototype.toJSON = function () {
  return this.toString();
};

const app = createApp();

initViewsAndTriggers()
  .then(() => initProcedures())
  .then(() => {
    app.listen(env.port, () => {
      console.log(`Server is running at http://localhost:${env.port}`);
    });
  })
  .catch((error) => {
    console.error("启动失败:", error);
    process.exit(1);
  });



