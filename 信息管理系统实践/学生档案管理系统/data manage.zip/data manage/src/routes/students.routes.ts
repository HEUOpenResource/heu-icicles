import { Router } from "express";
import { pool } from "../config/db.js";
import { auth } from "../middleware/auth.js";
import { Status } from "../types/index.js";

export const studentRouter = Router();

studentRouter.get("/", auth(), async (req, res, next) => {
  try {
    const page = Number(req.query.page ?? 1);
    const pageSize = Number(req.query.pageSize ?? 10);
    const keyword = (req.query.keyword as string) ?? "";
    const classId = req.query.classId ? Number(req.query.classId as string) : undefined;
    const status = (req.query.status as Status) || undefined;

    const whereConditions: string[] = [];
    const params: any[] = [];

    if (keyword) {
      whereConditions.push("(s.name LIKE ? OR s.student_no LIKE ?)");
      params.push(`%${keyword}%`, `%${keyword}%`);
    }
    if (classId) {
      whereConditions.push("s.class_id = ?");
      params.push(classId);
    }
    if (status) {
      whereConditions.push("s.status = ?");
      params.push(status);
    }

    const whereClause = whereConditions.length > 0 
      ? `WHERE ${whereConditions.join(" AND ")}` 
      : "";

    const [countRows] = await pool.execute(
      `SELECT COUNT(*) as total FROM \`student\` s ${whereClause}`,
      params
    );
    const total = Number((countRows as any[])[0].total);

    const limitValue = Number(pageSize);
    const offsetValue = Number((page - 1) * pageSize);
    const [rows] = await pool.execute(
      `SELECT 
        s.id,
        s.student_no,
        s.name,
        s.gender,
        s.nation,
        s.birthday,
        s.id_card,
        s.class_id,
        s.status,
        s.enroll_date,
        s.graduate_date,
        s.remark,
        c.id as class_id_rel,
        c.name as class_name,
        c.grade as class_grade
      FROM \`student\` s
      LEFT JOIN \`class\` c ON s.class_id = c.id
      ${whereClause}
      ORDER BY s.id DESC
      LIMIT ${limitValue} OFFSET ${offsetValue}`,
      params
    );

    const studentIds = (rows as any[]).map((row: any) => Number(row.id));
    
    let awardsMap: Record<string, any[]> = {};
    if (studentIds.length > 0) {
      const placeholders = studentIds.map(() => '?').join(',');
      const [awardsRows] = await pool.execute(
        `SELECT id, student_id, type, title, level, date, description 
         FROM \`awardspunishment\` 
         WHERE student_id IN (${placeholders})
         ORDER BY date DESC`,
        studentIds
      );
      
      (awardsRows as any[]).forEach((award: any) => {
        const studentId = String(award.student_id);
        if (!awardsMap[studentId]) {
          awardsMap[studentId] = [];
        }
        awardsMap[studentId].push({
          id: String(award.id),
          studentId: studentId,
          type: award.type,
          title: award.title,
          level: award.level,
          date: award.date ? new Date(award.date).toISOString().split('T')[0] : null,
          description: award.description,
        });
      });
    }

    const list = (rows as any[]).map((row: any) => {
      const student: any = {
        id: String(row.id),
        studentNo: row.student_no,
        name: row.name,
        gender: row.gender,
        nation: row.nation,
        birthday: row.birthday ? new Date(row.birthday).toISOString().split('T')[0] : null,
        idCard: row.id_card,
        classId: row.class_id ? String(row.class_id) : null,
        status: row.status,
        enrollDate: row.enroll_date ? new Date(row.enroll_date).toISOString().split('T')[0] : null,
        graduateDate: row.graduate_date ? new Date(row.graduate_date).toISOString().split('T')[0] : null,
        remark: row.remark,
      };

      if (row.class_id_rel) {
        student.Class = {
          id: String(row.class_id_rel),
          name: row.class_name,
          grade: row.class_grade,
        };
      } else {
        student.Class = null;
      }

      student.Awards = awardsMap[String(row.id)] || [];

      return student;
    });

    res.json({ total, list, page, pageSize });
  } catch (err) {
    next(err);
  }
});

studentRouter.post("/", auth(), async (req, res, next) => {
  try {
    const data = req.body;
    const [result] = await pool.execute(
      `INSERT INTO \`student\` (student_no, name, gender, nation, birthday, id_card, 
        class_id, status, enroll_date, graduate_date, remark) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        data.studentNo || null,
        data.name || null,
        data.gender || "male",
        data.nation || null,
        data.birthday || null,
        data.idCard || null,
        data.classId ? Number(data.classId) : null,
        data.status || "enrolled",
        data.enrollDate || null,
        data.graduateDate || null,
        data.remark || null,
      ]
    );

    const insertId = (result as any).insertId;
    const [rows] = await pool.execute(
      `SELECT * FROM \`student\` WHERE id = ?`,
      [insertId]
    );

    const student = (rows as any[])[0];
    if (student) {
      student.id = String(student.id);
      if (student.class_id) student.class_id = String(student.class_id);
    }
    res.status(201).json(student);
  } catch (err: any) {
    if (err.code === "ER_DUP_ENTRY") {
      return res.status(400).json({ message: "学号已存在" });
    }
    next(err);
  }
});

studentRouter.get("/:id", auth(), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const [rows] = await pool.execute(
      `SELECT 
        s.id,
        s.student_no,
        s.name,
        s.gender,
        s.nation,
        s.birthday,
        s.id_card,
        s.class_id,
        s.status,
        s.enroll_date,
        s.graduate_date,
        s.remark,
        c.id as class_id_rel,
        c.name as class_name,
        c.grade as class_grade
      FROM \`student\` s
      LEFT JOIN \`class\` c ON s.class_id = c.id
      WHERE s.id = ?`,
      [id]
    );

    const resultRows = rows as any[];
    if (resultRows.length === 0) {
      return res.status(404).json({ message: "学生不存在" });
    }

    const row = resultRows[0];
    
    const [awardsRows] = await pool.execute(
      `SELECT id, student_id, type, title, level, date, description 
       FROM \`awardspunishment\` 
       WHERE student_id = ?
       ORDER BY date DESC`,
      [id]
    );

    const student: any = {
      id: String(row.id),
      studentNo: row.student_no,
      name: row.name,
      gender: row.gender,
      nation: row.nation,
      birthday: row.birthday ? new Date(row.birthday).toISOString().split('T')[0] : null,
      idCard: row.id_card,
      classId: row.class_id ? String(row.class_id) : null,
      status: row.status,
      enrollDate: row.enroll_date ? new Date(row.enroll_date).toISOString().split('T')[0] : null,
      graduateDate: row.graduate_date ? new Date(row.graduate_date).toISOString().split('T')[0] : null,
      remark: row.remark,
    };

    if (row.class_id_rel) {
      student.Class = {
        id: String(row.class_id_rel),
        name: row.class_name,
        grade: row.class_grade,
      };
    } else {
      student.Class = null;
    }

    student.Awards = (awardsRows as any[]).map((a: any) => ({
      id: String(a.id),
      studentId: String(a.student_id),
      type: a.type,
      title: a.title,
      level: a.level,
      date: a.date ? new Date(a.date).toISOString().split('T')[0] : null,
      description: a.description,
    }));

    res.json(student);
  } catch (err) {
    next(err);
  }
});

studentRouter.patch("/:id", auth(), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const data = req.body;

    const fieldMap: Record<string, string> = {
      studentNo: "student_no",
      idCard: "id_card",
      classId: "class_id",
      enrollDate: "enroll_date",
      graduateDate: "graduate_date",
    };

    const updates: string[] = [];
    const values: any[] = [];

    Object.keys(data).forEach((key) => {
      if (data[key] !== undefined && key !== "id") {
        const dbField = fieldMap[key] || key;
        updates.push(`${dbField} = ?`);
        let value = data[key];
        if (value === "") {
          value = null;
        }
        if (key === "classId" && value !== null && value !== undefined && value !== "") {
          value = Number(value);
        }
        values.push(value);
      }
    });

    if (updates.length === 0) {
      return res.status(400).json({ message: "没有要更新的字段" });
    }

    values.push(id);
    await pool.execute(
      `UPDATE \`student\` SET ${updates.join(", ")} WHERE id = ?`,
      values
    );

    const [rows] = await pool.execute(
      `SELECT * FROM \`student\` WHERE id = ?`,
      [id]
    );

    const student = (rows as any[])[0];
    if (student) {
      student.id = String(student.id);
      if (student.class_id) student.class_id = String(student.class_id);
    }
    res.json(student);
  } catch (err) {
    next(err);
  }
});

studentRouter.delete("/:id", auth(), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    await pool.execute(`DELETE FROM \`student\` WHERE id = ?`, [id]);
    res.status(204).end();
  } catch (err) {
    next(err);
  }
});

studentRouter.patch("/:id/status", auth(), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const status = req.body.status as Status;
    
    await pool.execute(`UPDATE \`student\` SET status = ? WHERE id = ?`, [status, id]);
    
    const [rows] = await pool.execute(
      `SELECT * FROM \`student\` WHERE id = ?`,
      [id]
    );
    
    res.json((rows as any[])[0]);
  } catch (err) {
    next(err);
  }
});

studentRouter.post("/batch-update-status", auth(), async (req, res, next) => {
  try {
    const { studentIds, status } = req.body;
    
    if (!studentIds || !Array.isArray(studentIds) || studentIds.length === 0) {
      return res.status(400).json({ message: "学生ID列表不能为空" });
    }
    
    if (!status || !["enrolled", "suspended", "withdrawn", "graduated"].includes(status)) {
      return res.status(400).json({ message: "无效的学籍状态" });
    }
    
    const idsString = studentIds.map((id: any) => Number(id)).join(",");
    
    const [result] = await pool.query(
      `CALL batch_update_student_status(?, ?, @affected_rows)`,
      [idsString, status]
    );
    
    const [affected] = await pool.execute(`SELECT @affected_rows as affected_rows`);
    const affectedRows = Number((affected as any[])[0].affected_rows);
    
    res.json({
      message: "批量更新成功",
      affectedRows,
      studentIds,
      status,
    });
  } catch (err: any) {
    console.error("批量更新学生状态失败:", err);
    next(err);
  }
});
