import { Router } from "express";
import { pool } from "../config/db.js";
import { auth } from "../middleware/auth.js";

export const statsRouter = Router();

statsRouter.get("/status", auth(), async (_req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT status, COUNT(*) as _count FROM \`student\` GROUP BY status`
    );
    const result = (rows as any[]).map((row: any) => ({
      status: row.status,
      _count: Number(row._count),
    }));
    res.json(result);
  } catch (err) {
    next(err);
  }
});

statsRouter.get("/gender", auth(), async (_req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT gender, COUNT(*) as _count FROM \`student\` GROUP BY gender`
    );
    const result = (rows as any[]).map((row: any) => ({
      gender: row.gender,
      _count: Number(row._count),
    }));
    res.json(result);
  } catch (err) {
    next(err);
  }
});

statsRouter.get("/awards", auth(), async (_req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT type, COUNT(*) as _count FROM \`awardspunishment\` GROUP BY type`
    );
    const result = (rows as any[]).map((row: any) => ({
      type: row.type,
      _count: Number(row._count),
    }));
    res.json(result);
  } catch (err) {
    next(err);
  }
});
