import { Router } from "express";
import { pool } from "../config/db.js";
import { auth } from "../middleware/auth.js";

export const viewsRouter = Router();

viewsRouter.get("/student-class", auth(), async (_req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT * FROM v_student_class ORDER BY student_id DESC LIMIT 100`
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});

viewsRouter.get("/student-awards", auth(), async (req, res, next) => {
  try {
    const studentNo = req.query.studentNo as string | undefined;
    
    if (studentNo) {
      const [rows] = await pool.execute(
        `SELECT * FROM v_student_awards WHERE student_no = ? ORDER BY date DESC`,
        [studentNo]
      );
      res.json(rows);
    } else {
      const [rows] = await pool.execute(
        `SELECT * FROM v_student_awards ORDER BY date DESC LIMIT 100`
      );
      res.json(rows);
    }
  } catch (err) {
    next(err);
  }
});

viewsRouter.get("/student-status", auth(), async (req, res, next) => {
  try {
    const status = req.query.status as string | undefined;
    
    if (status) {
      const [rows] = await pool.execute(
        `SELECT * FROM v_student_status WHERE status = ? ORDER BY student_id DESC`,
        [status]
      );
      res.json(rows);
    } else {
      const [rows] = await pool.execute(
        `SELECT * FROM v_student_status ORDER BY student_id DESC LIMIT 100`
      );
      res.json(rows);
    }
  } catch (err) {
    next(err);
  }
});

viewsRouter.get("/list", auth(), async (_req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT TABLE_NAME 
       FROM information_schema.VIEWS 
       WHERE TABLE_SCHEMA = DATABASE()
       ORDER BY TABLE_NAME`
    );
    const views = (rows as any[]).map((v: any) => v.TABLE_NAME);
    res.json(views);
  } catch (err) {
    next(err);
  }
});

viewsRouter.get("/triggers", auth(), async (_req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT TRIGGER_NAME, EVENT_MANIPULATION, EVENT_OBJECT_TABLE
       FROM information_schema.TRIGGERS 
       WHERE TRIGGER_SCHEMA = DATABASE()
       ORDER BY TRIGGER_NAME`
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
});
