import { Router } from "express";
import { pool } from "../config/db.js";
import { auth } from "../middleware/auth.js";
import { AwardType } from "../types/index.js";

export const awardRouter = Router();

awardRouter.get("/", auth(), async (req, res, next) => {
  try {
    const studentId = req.query.studentId
      ? Number(req.query.studentId as string)
      : undefined;
    const type = (req.query.type as AwardType) || undefined;

    const whereConditions: string[] = [];
    const params: any[] = [];

    if (studentId) {
      whereConditions.push("student_id = ?");
      params.push(studentId);
    }
    if (type) {
      whereConditions.push("type = ?");
      params.push(type);
    }

    const whereClause = whereConditions.length > 0 
      ? `WHERE ${whereConditions.join(" AND ")}` 
      : "";

    const [rows] = await pool.execute(
      `SELECT * FROM \`awardspunishment\` ${whereClause} ORDER BY date DESC`,
      params
    );

    const awards = (rows as any[]).map((a: any) => ({
      ...a,
      id: String(a.id),
      studentId: String(a.student_id),
      date: a.date ? new Date(a.date).toISOString().split('T')[0] : null,
    }));
    res.json(awards);
  } catch (err) {
    next(err);
  }
});

awardRouter.post("/", auth(), async (req, res, next) => {
  try {
    const { studentId, type, title, level, date, description } = req.body;
    if (!studentId) {
      return res.status(400).json({ message: "学生ID不能为空" });
    }
    const [result] = await pool.execute(
      `INSERT INTO \`awardspunishment\` (student_id, type, title, level, date, description) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [Number(studentId), type, title, level || null, date || null, description || null]
    );

    const insertId = (result as any).insertId;
    const [rows] = await pool.execute(
      `SELECT * FROM \`awardspunishment\` WHERE id = ?`,
      [insertId]
    );

    const award = (rows as any[])[0];
    if (award) {
      award.id = String(award.id);
      award.studentId = String(award.student_id);
      if (award.date) award.date = new Date(award.date).toISOString().split('T')[0];
    }
    res.status(201).json(award);
  } catch (err) {
    next(err);
  }
});

awardRouter.patch("/:id", auth(), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const data = req.body;

    const fieldMap: Record<string, string> = {
      studentId: "student_id",
    };

    const updates: string[] = [];
    const values: any[] = [];

    Object.keys(data).forEach((key) => {
      if (data[key] !== undefined && key !== "id") {
        const dbField = fieldMap[key] || key;
        updates.push(`${dbField} = ?`);
        let value = data[key];
        if (value === "") {
          value = null;
        }
        if (key === "studentId" && value !== null && value !== undefined && value !== "") {
          value = Number(value);
        }
        values.push(value);
      }
    });

    if (updates.length === 0) {
      return res.status(400).json({ message: "没有要更新的字段" });
    }

    values.push(id);
    await pool.execute(
      `UPDATE \`awardspunishment\` SET ${updates.join(", ")} WHERE id = ?`,
      values
    );

    const [rows] = await pool.execute(
      `SELECT * FROM \`awardspunishment\` WHERE id = ?`,
      [id]
    );

    const award = (rows as any[])[0];
    if (award) {
      award.id = String(award.id);
      award.studentId = String(award.student_id);
      if (award.date) award.date = new Date(award.date).toISOString().split('T')[0];
    }
    res.json(award);
  } catch (err) {
    next(err);
  }
});

awardRouter.delete("/:id", auth(), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    await pool.execute(`DELETE FROM \`awardspunishment\` WHERE id = ?`, [id]);
    res.status(204).end();
  } catch (err) {
    next(err);
  }
});
