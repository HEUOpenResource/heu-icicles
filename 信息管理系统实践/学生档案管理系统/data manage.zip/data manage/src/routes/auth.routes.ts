import { Router } from "express";
import { pool } from "../config/db.js";
import { verifyPassword } from "../utils/password.js";
import { signToken } from "../utils/jwt.js";
import { auth, AuthedRequest } from "../middleware/auth.js";

export const authRouter = Router();

authRouter.post("/login", async (req, res, next) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ message: "用户名或密码不能为空" });
    }
    
    const [rows] = await pool.execute(
      `SELECT id, username, password_hash, role, realname, status FROM \`user\` WHERE username = ?`,
      [username]
    );
    
    const users = rows as any[];
    if (users.length === 0) {
      return res.status(401).json({ message: "用户名或密码错误" });
    }
    
    const user = users[0];
    if (password !== user.password_hash) {
      return res.status(401).json({ message: "用户名或密码错误" });
    }
    
    if (user.status === 0) {
      return res.status(403).json({ message: "账号已禁用" });
    }
    
    const token = signToken({
      userId: BigInt(user.id),
      role: user.role,
      username: user.username,
    });
    
    res.json({
      token,
      user: {
        id: String(user.id),
        username: user.username,
        role: user.role,
        realname: user.realname,
      },
    });
  } catch (err: any) {
    console.error("登录错误:", err);
    next(err);
  }
});

authRouter.get("/me", auth(), async (req: AuthedRequest, res, next) => {
  try {
    const userId = req.user!.userId;
    const [rows] = await pool.execute(
      `SELECT id, username, role, realname, status FROM \`user\` WHERE id = ?`,
      [Number(userId)]
    );
    
    const users = rows as any[];
    if (users.length === 0) {
      return res.status(404).json({ message: "用户不存在" });
    }
    
    const user = users[0];
    user.id = String(user.id);
    res.json(user);
  } catch (err) {
    next(err);
  }
});
