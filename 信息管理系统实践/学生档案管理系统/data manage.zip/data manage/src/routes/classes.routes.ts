import { Router } from "express";
import { pool } from "../config/db.js";
import { auth } from "../middleware/auth.js";

export const classRouter = Router();

classRouter.get("/", auth(), async (_req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT * FROM \`class\` ORDER BY grade DESC, id DESC`
    );
    const classes = (rows as any[]).map((c: any) => ({
      ...c,
      id: String(c.id),
    }));
    res.json(classes);
  } catch (err) {
    next(err);
  }
});

classRouter.post("/", auth(), async (req, res, next) => {
  try {
    const { name, grade } = req.body;
    const [result] = await pool.execute(
      `INSERT INTO \`class\` (name, grade) VALUES (?, ?)`,
      [name, grade || null]
    );
    
    const insertId = (result as any).insertId;
    const [rows] = await pool.execute(
      `SELECT * FROM \`class\` WHERE id = ?`,
      [insertId]
    );
    
    const cls = (rows as any[])[0];
    if (cls) {
      cls.id = String(cls.id);
    }
    res.status(201).json(cls);
  } catch (err: any) {
    if (err.code === "ER_DUP_ENTRY") {
      return res.status(400).json({ message: "班级已存在" });
    }
    next(err);
  }
});

classRouter.patch("/:id", auth(), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const data = req.body;
    
    const updates: string[] = [];
    const values: any[] = [];
    
    Object.keys(data).forEach((key) => {
      if (data[key] !== undefined && key !== "id") {
        updates.push(`${key} = ?`);
        values.push(data[key]);
      }
    });
    
    if (updates.length === 0) {
      return res.status(400).json({ message: "没有要更新的字段" });
    }
    
    values.push(id);
    await pool.execute(
      `UPDATE \`class\` SET ${updates.join(", ")} WHERE id = ?`,
      values
    );
    
    const [rows] = await pool.execute(
      `SELECT * FROM \`class\` WHERE id = ?`,
      [id]
    );
    
    const cls = (rows as any[])[0];
    if (cls) {
      cls.id = String(cls.id);
    }
    res.json(cls);
  } catch (err) {
    next(err);
  }
});

classRouter.delete("/:id", auth(), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    await pool.execute(`DELETE FROM \`class\` WHERE id = ?`, [id]);
    res.status(204).end();
  } catch (err) {
    next(err);
  }
});
