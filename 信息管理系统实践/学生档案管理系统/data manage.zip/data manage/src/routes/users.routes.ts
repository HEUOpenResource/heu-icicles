import { Router } from "express";
import { pool } from "../config/db.js";
import { auth, AuthedRequest } from "../middleware/auth.js";
import { Role } from "../types/index.js";
import { hashPassword } from "../utils/password.js";

export const userRouter = Router();

userRouter.post("/", auth([Role.admin]), async (req: AuthedRequest, res, next) => {
  try {
    const { username, password, role, realname } = req.body;
    if (!username || !password) {
      return res.status(400).json({ message: "用户名和密码必填" });
    }
    const passwordHash = await hashPassword(password);
    
    const [result] = await pool.execute(
      `INSERT INTO \`user\` (username, password_hash, role, realname) VALUES (?, ?, ?, ?)`,
      [username, passwordHash, role ?? Role.operator, realname || null]
    );
    
    const insertId = (result as any).insertId;
    const [rows] = await pool.execute(
      `SELECT id, username, role, realname FROM \`user\` WHERE id = ?`,
      [insertId]
    );
    
    const user = (rows as any[])[0];
    if (user) {
      user.id = String(user.id);
    }
    res.status(201).json(user);
  } catch (err: any) {
    if (err.code === "ER_DUP_ENTRY") {
      return res.status(400).json({ message: "用户名已存在" });
    }
    next(err);
  }
});

userRouter.get("/", auth([Role.admin]), async (_req, res, next) => {
  try {
    const [rows] = await pool.execute(
      `SELECT id, username, role, realname, status FROM \`user\` ORDER BY id DESC`
    );
    const users = (rows as any[]).map((u: any) => ({
      ...u,
      id: String(u.id),
    }));
    res.json(users);
  } catch (err) {
    next(err);
  }
});

userRouter.patch("/password", auth(), async (req: AuthedRequest, res, next) => {
  try {
    const { password } = req.body;
    if (!password) {
      return res.status(400).json({ message: "新密码不能为空" });
    }
    const passwordHash = await hashPassword(password);
    await pool.execute(
      `UPDATE \`user\` SET password_hash = ? WHERE id = ?`,
      [passwordHash, Number(req.user!.userId)]
    );
    res.json({ message: "密码已更新" });
  } catch (err) {
    next(err);
  }
});

userRouter.patch("/:id", auth([Role.admin]), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const { role, status } = req.body;
    
    const updates: string[] = [];
    const values: any[] = [];
    
    if (role !== undefined) {
      updates.push("role = ?");
      values.push(role);
    }
    if (status !== undefined) {
      updates.push("status = ?");
      values.push(status);
    }
    
    if (updates.length === 0) {
      return res.status(400).json({ message: "没有要更新的字段" });
    }
    
    values.push(id);
    await pool.execute(
      `UPDATE \`user\` SET ${updates.join(", ")} WHERE id = ?`,
      values
    );
    
    const [rows] = await pool.execute(
      `SELECT id, username, role, status FROM \`user\` WHERE id = ?`,
      [id]
    );
    
    const user = (rows as any[])[0];
    if (user) {
      user.id = String(user.id);
    }
    res.json(user);
  } catch (err) {
    next(err);
  }
});
