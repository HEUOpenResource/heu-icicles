import { Router } from "express";
import { readdir } from "fs/promises";
import { extname, resolve } from "path";
import { env } from "../config/env.js";

export const systemRouter = Router();

systemRouter.get("/health", async (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

systemRouter.get("/random-background", async (_req, res, next) => {
  try {
    const backgroundsDir = resolve(env.backgroundsDir || "./public/backgrounds");
    const imageExtensions = [".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"];
    
    try {
      const files = await readdir(backgroundsDir);
      const imageFiles = files.filter((file) =>
        imageExtensions.includes(extname(file).toLowerCase())
      );

      if (imageFiles.length === 0) {
        return res.json({ url: null, message: "背景图片文件夹为空" });
      }

      const randomFile = imageFiles[Math.floor(Math.random() * imageFiles.length)];
      const imageUrl = `/backgrounds/${randomFile}`;

      res.json({ url: imageUrl });
    } catch (error: any) {
      if (error.code === "ENOENT") {
        return res.json({ url: null, message: "背景图片文件夹不存在" });
      }
      throw error;
    }
  } catch (err) {
    next(err);
  }
});

