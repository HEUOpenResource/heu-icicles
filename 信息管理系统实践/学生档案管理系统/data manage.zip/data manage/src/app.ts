import express from "express";
import cors from "cors";
import { resolve } from "path";
import { router } from "./routes.js";
import { errorHandler } from "./middleware/error.js";
import { env } from "./config/env.js";

export function createApp() {
  const app = express();
  app.use(cors());
  app.use(express.json({ limit: "5mb" }));
  app.use(express.urlencoded({ extended: true }));

  const backgroundsDir = resolve(env.backgroundsDir || "./public/backgrounds");
  app.use("/backgrounds", express.static(backgroundsDir));

  app.use("/api", router);
  app.use(errorHandler);

  return app;
}




