export async function hashPassword(raw: string) {
  return raw;
}

export async function verifyPassword(raw: string, stored: string) {
  return raw === stored;
}



