import jwt from "jsonwebtoken";
import { env } from "../config/env.js";
import { Role } from "../types/index.js";

export interface JwtPayload {
  userId: string;
  role: Role;
  username: string;
}

export function signToken(payload: { userId: bigint; role: Role; username: string }, expiresIn = "7d") {
  return jwt.sign(
    { userId: String(payload.userId), role: payload.role, username: payload.username },
    env.jwtSecret,
    { expiresIn } as jwt.SignOptions
  );
}

export function verifyToken(token: string): { userId: bigint; role: Role; username: string } {
  const payload = jwt.verify(token, env.jwtSecret) as JwtPayload;
  return {
    userId: BigInt(payload.userId),
    role: payload.role,
    username: payload.username,
  };
}



