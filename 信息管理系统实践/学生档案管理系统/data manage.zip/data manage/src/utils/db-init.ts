import { pool } from "../config/db.js";
import { readFileSync } from "fs";
import { join } from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export async function initViewsAndTriggers() {
  try {
    console.log("开始初始化数据库视图和触发器...");

    const sqlPath = join(__dirname, "../../db/views_and_triggers.sql");
    let sql = readFileSync(sqlPath, "utf-8");

    sql = sql.replace(/--.*$/gm, "");

    const triggerPattern = /DROP TRIGGER IF EXISTS\s+(\w+);[\s\S]*?CREATE TRIGGER\s+(\w+)[\s\S]*?DELIMITER\s*;/g;
    const triggers: Array<{ drop: string; create: string; name: string }> = [];
    let match;
    
    while ((match = triggerPattern.exec(sql)) !== null) {
      const triggerName = match[2];
      const triggerSql = match[0]
        .replace(/DELIMITER\s+\$\$/g, "")
        .replace(/\$\$/g, ";")
        .replace(/DELIMITER\s*;/g, "");
      
      const dropMatch = triggerSql.match(/DROP TRIGGER IF EXISTS\s+\w+;/i);
      const createMatch = triggerSql.match(/CREATE TRIGGER[\s\S]+?END;/i);
      
      if (dropMatch && createMatch) {
        triggers.push({
          drop: dropMatch[0],
          create: createMatch[0],
          name: triggerName,
        });
      }
    }

    sql = sql.replace(/DROP TRIGGER IF EXISTS\s+\w+;[\s\S]*?DELIMITER\s*;/g, "");

    sql = sql.replace(/DELIMITER\s+\$\$/g, "");
    sql = sql.replace(/\$\$/g, ";");
    sql = sql.replace(/DELIMITER\s*;/g, "");

    const statements = sql
      .split(";")
      .map((s) => s.trim())
      .filter((s) => s.length > 0 && !s.match(/^\s*$/));

    for (const statement of statements) {
      if (!statement || statement.length === 0) continue;

      try {
        await pool.execute(statement);
        
        const viewMatch = statement.match(/CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+(\w+)/i);
        if (viewMatch) {
          console.log(`✓ 视图创建/更新成功: ${viewMatch[1]}`);
          continue;
        }
      } catch (error: any) {
        const errorMsg = error.message || String(error);
        
        if (errorMsg.includes("already exists") || 
            error.code === "ER_TABLE_EXISTS_ERROR") {
          
          const viewMatch = statement.match(/CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+(\w+)/i);
          if (viewMatch) {
            try {
              await pool.execute(`DROP VIEW IF EXISTS ${viewMatch[1]}`);
              await pool.execute(statement);
              console.log(`✓ 视图重建成功: ${viewMatch[1]}`);
            } catch (retryError: any) {
              console.log(`⚠ 视图可能已存在: ${viewMatch[1]}`);
            }
          }
        } else {
          console.error(`✗ SQL执行失败:`, errorMsg);
          const preview = statement.substring(0, 150).replace(/\n/g, " ");
          console.error(`  语句预览: ${preview}...`);
        }
      }
    }

    for (const trigger of triggers) {
      try {
        await pool.query(trigger.drop);
        await pool.query(trigger.create);
        console.log(`✓ 触发器创建成功: ${trigger.name}`);
      } catch (error: any) {
        const errorMsg = error.message || String(error);
        if (errorMsg.includes("already exists") || error.code === "ER_TRG_ALREADY_EXISTS") {
          try {
            await pool.query(trigger.drop);
            await pool.query(trigger.create);
            console.log(`✓ 触发器重建成功: ${trigger.name}`);
          } catch (retryError: any) {
            console.log(`⚠ 触发器创建失败: ${trigger.name} - ${retryError.message}`);
          }
        } else {
          console.error(`✗ 触发器创建失败: ${trigger.name} - ${errorMsg}`);
        }
      }
    }

    console.log("数据库视图和触发器初始化完成！");
  } catch (error: any) {
    console.error("初始化数据库视图和触发器时出错:", error.message);
    throw error;
  }
}

export async function initProcedures() {
  try {
    console.log("开始初始化数据库存储过程...");

    const sqlPath = join(__dirname, "../../db/procedures.sql");
    let sql = readFileSync(sqlPath, "utf-8");

    sql = sql.replace(/--.*$/gm, "");

    const procedurePattern = /DROP PROCEDURE IF EXISTS\s+(\w+);[\s\S]*?CREATE PROCEDURE\s+(\w+)[\s\S]*?END\$\$[\s\S]*?DELIMITER\s*;/g;
    const procedures: Array<{ drop: string; create: string; name: string }> = [];
    let match;
    
    while ((match = procedurePattern.exec(sql)) !== null) {
      const procedureName = match[2];
      const fullMatch = match[0];
      
      const dropMatch = fullMatch.match(/DROP PROCEDURE IF EXISTS\s+\w+;/i);
      
      const createMatch = fullMatch.match(/CREATE PROCEDURE[\s\S]+?END\$\$/i);
      
      if (dropMatch && createMatch) {
        const createSql = createMatch[0].replace(/\$\$/g, ";");
        
        procedures.push({
          drop: dropMatch[0],
          create: createSql,
          name: procedureName,
        });
      }
    }

    for (const procedure of procedures) {
      try {
        await pool.query(procedure.drop);
        await pool.query(procedure.create);
        console.log(`✓ 存储过程创建成功: ${procedure.name}`);
      } catch (error: any) {
        const errorMsg = error.message || String(error);
        if (errorMsg.includes("already exists")) {
          try {
            await pool.query(procedure.drop);
            await pool.query(procedure.create);
            console.log(`✓ 存储过程重建成功: ${procedure.name}`);
          } catch (retryError: any) {
            console.log(`⚠ 存储过程创建失败: ${procedure.name} - ${retryError.message}`);
          }
        } else {
          console.error(`✗ 存储过程创建失败: ${procedure.name} - ${errorMsg}`);
        }
      }
    }

    console.log("数据库存储过程初始化完成！");
  } catch (error: any) {
    console.error("初始化数据库存储过程时出错:", error.message);
  }
}

export async function checkViewsExist(): Promise<boolean> {
  try {
    const [rows] = await pool.execute(
      `SELECT TABLE_NAME 
       FROM information_schema.VIEWS 
       WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME IN ('v_student_class', 'v_student_awards', 'v_student_status')`
    );
    return (rows as any[]).length === 3;
  } catch (error) {
    return false;
  }
}

export async function checkTriggersExist(): Promise<boolean> {
  try {
    const [rows] = await pool.execute(
      `SELECT TRIGGER_NAME 
       FROM information_schema.TRIGGERS 
       WHERE TRIGGER_SCHEMA = DATABASE()
       AND TRIGGER_NAME IN ('after_student_insert', 'after_student_delete')`
    );
    return (rows as any[]).length === 2;
  } catch (error) {
    return false;
  }
}
