import mysql from "mysql2/promise";
import { env } from "./env.js";

function parseDatabaseUrl() {
  const url = env.databaseUrl;
  if (url && url.startsWith("mysql://")) {
    const match = url.match(/mysql:\/\/([^:]+):([^@]+)@([^:]+):(\d+)\/(.+)/);
    if (match) {
      return {
        host: match[3],
        port: parseInt(match[4]),
        user: match[1],
        password: match[2],
        database: match[5],
      };
    }
  }
  
  return {
    host: process.env.DB_HOST || process.env.MYSQL_HOST || "localhost",
    port: parseInt(process.env.DB_PORT || process.env.MYSQL_PORT || "3306"),
    user: process.env.DB_USER || process.env.MYSQL_USER || "root",
    password: process.env.DB_PASSWORD || process.env.MYSQL_PASSWORD || "",
    database: process.env.DB_NAME || process.env.MYSQL_DATABASE || "student_archive",
  };
}

const dbConfig = parseDatabaseUrl();

export const pool = mysql.createPool({
  ...dbConfig,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  enableKeepAlive: true,
  keepAliveInitialDelay: 0,
});

pool
  .getConnection()
  .then(async (connection) => {
    console.log("✓ 数据库连接成功");
    try {
      const [rows] = await connection.execute("SHOW TABLES");
      console.log("✓ 数据库表:", (rows as any[]).map((r: any) => Object.values(r)[0]).join(", "));
    } catch (err: any) {
      console.error("✗ 查询表失败:", err.message);
    }
    connection.release();
  })
  .catch((err) => {
    console.error("✗ 数据库连接失败:", err.message);
    console.error("数据库配置:", {
      host: dbConfig.host,
      port: dbConfig.port,
      user: dbConfig.user,
      database: dbConfig.database,
    });
  });

