import dotenv from "dotenv";
dotenv.config();

import mysql from "mysql2/promise";
import bcrypt from "bcryptjs";

async function fixRootUser() {
  let connection;
  try {
    const pool = mysql.createPool({
      host: process.env.DB_HOST || "localhost",
      port: Number(process.env.DB_PORT) || 3306,
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "",
      database: process.env.DB_NAME || "student_archive",
    });

    console.log("连接数据库...");
    
    const [rows] = await pool.execute("SELECT id, username, role, password FROM `user` WHERE username = ?", ["root"]);
    const users = rows as any[];
    
    if (users.length === 0) {
      console.log("root 用户不存在，正在创建...");
      const hashedPassword = await bcrypt.hash("sunguojun", 10);
      const [result] = await pool.execute(
        "INSERT INTO `user` (username, password, role) VALUES (?, ?, ?)",
        ["root", hashedPassword, "admin"]
      );
      console.log("✓ root 用户创建成功");
      console.log("  用户名: root");
      console.log("  密码: sunguojun");
      console.log("  角色: admin");
    } else {
      const user = users[0];
      console.log("root 用户已存在，正在重置密码...");
      
      const hashedPassword = await bcrypt.hash("sunguojun", 10);
      await pool.execute(
        "UPDATE `user` SET password = ? WHERE username = ?",
        [hashedPassword, "root"]
      );
      console.log("✓ root 用户密码已重置");
      
      const testPassword = await bcrypt.compare("sunguojun", hashedPassword);
      console.log(`密码验证测试: ${testPassword ? "✓ 通过" : "✗ 失败"}`);
      
      console.log("\n当前用户信息:");
      console.log(`  ID: ${user.id}`);
      console.log(`  用户名: ${user.username}`);
      console.log(`  角色: ${user.role}`);
    }
    
    const [allUsers] = await pool.execute("SELECT id, username, role FROM `user`");
    console.log("\n所有用户列表:");
    console.table(allUsers);
    
    await pool.end();
    process.exit(0);
  } catch (err: any) {
    console.error("错误:", err.message);
    if (err.code === "ER_ACCESS_DENIED_ERROR") {
      console.error("\n数据库连接失败！请检查:");
      console.error("1. MySQL 服务是否运行");
      console.error("2. 数据库用户名和密码是否正确");
      console.error("3. 是否创建了 .env 文件配置数据库连接");
    }
    process.exit(1);
  }
}

fixRootUser();


