-- 重置 root 用户密码为 sunguojun
USE student_archive;

-- 如果 root 用户不存在，创建它
INSERT INTO `user` (username, password, role) 
SELECT 'root', '$2a$10$YElhujE4y2qMvxQ19Nhz2e1aiRyzj295WqoxokQ0tU4hwd9IkD7xm', 'admin'
WHERE NOT EXISTS (SELECT 1 FROM `user` WHERE username = 'root');

-- 如果 root 用户已存在，更新密码
UPDATE `user` 
SET password = '$2a$10$YElhujE4y2qMvxQ19Nhz2e1aiRyzj295WqoxokQ0tU4hwd9IkD7xm'
WHERE username = 'root';

-- 查看结果
SELECT id, username, role, createdAt FROM `user` WHERE username = 'root';

