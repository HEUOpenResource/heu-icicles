import axios from "axios";

async function createRootUser() {
  try {
    const baseURL = "http://localhost:3000/api";
    
    console.log("尝试通过 API 创建 root 用户...");
    
    try {
      const registerResponse = await axios.post(`${baseURL}/auth/register`, {
        username: "root",
        password: "sunguojun",
        role: "admin"
      });
      console.log("✓ root 用户创建成功");
      console.log(registerResponse.data);
    } catch (err: any) {
      if (err.response?.status === 400 && err.response?.data?.message?.includes("已存在")) {
        console.log("root 用户已存在，尝试登录测试...");
        
        try {
          const loginResponse = await axios.post(`${baseURL}/auth/login`, {
            username: "root",
            password: "sunguojun"
          });
          console.log("✓ 登录成功！");
          console.log("Token:", loginResponse.data.token);
          console.log("用户信息:", loginResponse.data.user);
        } catch (loginErr: any) {
          console.log("✗ 登录失败");
          console.log("错误信息:", loginErr.response?.data?.message || loginErr.message);
          console.log("\n可能需要重置密码。");
          console.log("请使用以下 SQL 语句重置密码:");
          console.log("");
          console.log("UPDATE `user` SET password = '$2a$10$...' WHERE username = 'root';");
          console.log("");
          console.log("或者删除 root 用户后重新注册:");
          console.log("DELETE FROM `user` WHERE username = 'root';");
        }
      } else {
        console.error("注册失败:", err.response?.data || err.message);
      }
    }
  } catch (err: any) {
    console.error("连接后端 API 失败:", err.message);
    console.error("请确保后端服务正在运行 (http://localhost:3000)");
  }
}

createRootUser();


