import bcrypt from "bcryptjs";

async function generateHash() {
  const password = "sunguojun";
  const hash = await bcrypt.hash(password, 10);
  console.log("密码:", password);
  console.log("BCrypt 哈希值:", hash);
  console.log("");
  console.log("SQL 语句:");
  console.log(`UPDATE \`user\` SET password = '${hash}' WHERE username = 'root';`);
  console.log("");
  console.log("或者创建用户:");
  console.log(`INSERT INTO \`user\` (username, password, role) VALUES ('root', '${hash}', 'admin');`);
}

generateHash();


