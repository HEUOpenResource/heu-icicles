import pool from "../src/config/db.js";
import { hashPassword, comparePassword } from "../src/utils/password.js";

async function checkAndCreateUser() {
  try {
    console.log("检查数据库中的用户...");
    
    const [rows] = await pool.execute("SELECT id, username, role FROM `user` WHERE username = ?", ["root"]);
    const users = rows as any[];
    
    if (users.length === 0) {
      console.log("root 用户不存在，正在创建...");
      const hashedPassword = await hashPassword("sunguojun");
      const [result] = await pool.execute(
        "INSERT INTO `user` (username, password, role) VALUES (?, ?, ?)",
        ["root", hashedPassword, "admin"]
      );
      console.log("✓ root 用户创建成功");
    } else {
      console.log("root 用户已存在，正在重置密码...");
      const hashedPassword = await hashPassword("sunguojun");
      await pool.execute(
        "UPDATE `user` SET password = ? WHERE username = ?",
        [hashedPassword, "root"]
      );
      console.log("✓ root 用户密码已重置为: sunguojun");
      
      const testPassword = await comparePassword("sunguojun", hashedPassword);
      console.log(`密码验证测试: ${testPassword ? "✓ 通过" : "✗ 失败"}`);
    }
    
    const [allUsers] = await pool.execute("SELECT id, username, role FROM `user`");
    console.log("\n所有用户列表:");
    console.table(allUsers);
    
    process.exit(0);
  } catch (err) {
    console.error("错误:", err);
    process.exit(1);
  }
}

checkAndCreateUser();


